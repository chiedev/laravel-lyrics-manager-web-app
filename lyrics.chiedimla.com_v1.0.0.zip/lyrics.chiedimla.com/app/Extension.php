<?php namespace App;

use Illuminate\Database\Eloquent\Model as Eloquent;

class Extension extends Eloquent{
	//This is optional---the class "Extension" has the default table of its plural form "extensions"
	 protected $table = 'extensions';
}