<?php namespace App;

use Illuminate\Database\Eloquent\Model as Eloquent;

class Layout extends Eloquent{
	//This is optional---the class "Layout" has the default table of its plural form "layouts"
	 protected $table = 'layouts';
	// protected $timestamps = true ;
}