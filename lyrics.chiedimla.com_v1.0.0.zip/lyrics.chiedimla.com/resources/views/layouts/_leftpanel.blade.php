<div id="home">
	@yield('recent')
	@yield('soundcloud')
</div>
<div id="tools">
	@yield('tools')
	@yield('chords_used')
	@yield('similar')
</div>