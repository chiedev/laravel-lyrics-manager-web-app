<div id="footer">
	<div id="copyright">&copy2015 Stitch Songs | Powered by: Youtube, Spotify and SoundCloud</div>
</div>