<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
@yield('content')
</body>
</html>