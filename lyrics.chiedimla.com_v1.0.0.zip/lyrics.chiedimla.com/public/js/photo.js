$(document).ready(function(){
	alert('asdasd');
});