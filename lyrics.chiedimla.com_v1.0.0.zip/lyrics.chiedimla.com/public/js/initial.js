$(document).ready(function(){
	$(document).bind("contextmenu", function(e) {
        e.preventDefault();
    });
});