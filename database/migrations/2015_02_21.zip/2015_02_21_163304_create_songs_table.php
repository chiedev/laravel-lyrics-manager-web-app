<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSongsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('songs', function(Blueprint $table)
		{
			$table->increments('id')->unique();
			$table->integer('creator');
			$table->integer('saves')->nullable();
			$table->string('title');
			$table->text('lyrics');
			$table->string('artist')->nullable();
			$table->text('mp3');
			$table->string('slug');
			$table->integer('version');
			$table->rememberToken();
			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('songs');
	}

}
